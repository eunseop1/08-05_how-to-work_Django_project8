import matplotlib.pyplot as plt

plt.plot([1, 2, 3, 4], [1, 4, 9, 16])  # 첫번째 배열이 x축 두번째 배열이 y축으로 사용됨
plt.show()